<html>
<body>
    <h3>Alunos</h3>
    <ol>
        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($aluno['nome']); ?> | <a href = "<?php echo e(route('alunos.edit', $aluno['id'])); ?>">Editar</a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</body>
</html><?php /**PATH /home/anajulia/anajulia/ifsc/programacao_internet_II/trabalho1/resources/views/index.blade.php ENDPATH**/ ?>