<!DOCTYPE html>
<html>
    <body>
        <h3>DADOS DO ALUNO</h3>
        <p>ID: <?php echo e($aluno['id']); ?> </p>
        <p>Nome: <?php echo e($aluno['nome']); ?> </p>
        <p>Idade: <?php echo e($aluno['idade']); ?> </p>
        <p>Curso: <?php echo e($aluno['curso']); ?> </p>
        <p>Email: <?php echo e($aluno['email']); ?> </p>
        <br>

        <a href = "<?php echo e(route('alunos.index')); ?>">Voltar</a>
    
    </body>
</html><?php /**PATH /home/anajulia/anajulia/ifsc/programacao_internet_II/trabalho1/resources/views/aluno/info.blade.php ENDPATH**/ ?>