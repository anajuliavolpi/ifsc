<!DOCTYPE html>
<html>
    <body>
        <h3>NOVO ALUNO</h3>
        <form action="<?php echo e(route('alunos.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <br>Nome: <input type='text' name="nome"></br>
        <br>Idade: <input type='text' name="idade"></br>
        <br>Curso: <input type='text' name="curso"></br>
        <br>Email: <input type='text' name="email"></br>

        <input type='submit' value="Salvar">
        
        <a href = "<?php echo e(route('alunos.store')); ?>">Voltar</a>


        </form>

    </body>

</html><?php /**PATH /home/anajulia/anajulia/ifsc/programacao_internet_II/trabalho1/resources/views/aluno/create.blade.php ENDPATH**/ ?>