<html>
<body>
    <h3>Alunos</h3>
    <a href = "<?php echo e(route('alunos.create')); ?>">NOVO ALUNO</a>

    <ul>
        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php echo e($aluno['id']); ?>  |  <?php echo e($aluno['nome']); ?>  |  
            <a href = "<?php echo e(route('alunos.edit', $aluno['id'])); ?>">Editar  |  </a>
            <a href = "<?php echo e(route('alunos.show', $aluno['id'])); ?>">Mostrar</a>
            <form action="<?php echo e(route('alunos.destroy', $aluno['id'])); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Apagar">
            </form>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </ul>
</body>
</html><?php /**PATH /home/anajulia/anajulia/ifsc/programacao_internet_II/trabalho1/resources/views/aluno/index.blade.php ENDPATH**/ ?>