<!DOCTYPE html>
<html>
    <body>
        <h3>ATUALIZAR ALUNO</h3>
        <form action="<?php echo e(route('alunos.update', $aluno['id'])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <br>Nome: <input type='text' name="nome" value="<?php echo e($aluno['nome']); ?>"></br>
        <br>Idade: <input type='text' name="idade" value="<?php echo e($aluno['idade']); ?>"></br>
        <br>Curso: <input type='text' name="curso" value="<?php echo e($aluno['curso']); ?>"></br>
        <br>Email: <input type='text' name="email" value="<?php echo e($aluno['email']); ?>"></br>
        <input type='submit' value="Salvar">
        


        </form>

        <a href = "<?php echo e(route('alunos.index')); ?>">Voltar</a>
    </body>

</html><?php /**PATH /home/anajulia/anajulia/ifsc/programacao_internet_II/trabalho1/resources/views/aluno/edit.blade.php ENDPATH**/ ?>